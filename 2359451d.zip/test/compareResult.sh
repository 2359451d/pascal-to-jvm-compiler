#!/bin/bash

# ===============Compile Time Errors Comparison==================
# compare the compiler output with expected error files (generated from "gold standard compiler")

# ptj="java -jar ./target/pascal-to-jvm-compiler-jar-with-dependencies.jar"

filename=$@

# **********Initialising Operation
# perform flushing
# regenerate the comparelog for current CUT
# if [[ -e ./comparelog.patch ]];then
echo "**************************************************" > ./compareResultlog.patch
echo "Compare Result" >> ./compareResultlog.patch
echo "**************************************************" >> ./compareResultlog.patch
echo "" >> ./compareResultlog.patch
# fi
# **********

testcounter=0
testmatch=0
testunmatch=0
startTime=`date +%Y%m%d-%H:%M:%S`
startTime_s=`date +%s`
# compile each Pascal source file
for i in $filename
do
    if [[ ! -e $i ]]; then
        # if file does not exist
        continue
    fi

    if [[ $i == *.pas ]] ;then
        prefix=`echo $i | sed -r "s/(.*)\.pas/\1/g"`
        testcounter=$((testcounter+1))
        # echo $prefix

        # ptj run
        java -jar pascal-to-jvm-compiler-jar-with-dependencies.jar run $i |  tail -n +3 > ptjoutput
        rm -f ${prefix^}.class

        # fpc run
        fpc -MIso $i > /dev/null
        $(pwd)/$prefix > fpcoutput
        rm -f $prefix.o
        rm -f $prefix

        correctFlag1=0
        diff ptjoutput fpcoutput > /dev/null
        ret=$?
        if [[ $ret -eq 0 ]]; then
            correctFlag1=1
        fi

        # gpc run
        gpc $i >  /dev/null
        $(pwd)/a.out > gpcoutput
        rm -f a.out

        correctFlag2=0
        diff ptjoutput gpcoutput > /dev/null
        ret=$?
        if [[ $ret -eq 0 ]]; then
            correctFlag2=1
        fi

        # p5 run
        # p5 $prefix | awk 'NF' | sed -r "s/(.*)Running program/\1/g"
        # rm -f $prefix.p5

        rm -f fpcoutput,gpcoutput,ptjoutput
        if [[ $correctFlag1 = 1 ]] || [[ $correctFlag2 = 1 ]];then
            testmatch=$((testmatch+1))
        else
            testunmatch=$((testunmatch+1))
        fi
    fi
done

endTime=`date +%Y%m%d-%H:%M:%S`
endTime_s=`date +%s`
sumTime=$((endTime_s-startTime_s))

# generate test cases count, matched count, Unmatched count
info="Tese Case Count: [$testcounter], Matched: [$testmatch], Unmatched: [$testunmatch]"
timeusage=`echo "$startTime ---> $endTime" "Total:$sumTime seconds finished"`
echo -e "$(head -n2 ./compareResultlog.patch)\n$info\n$timeusage\n$(tail -n+3 ./compareResultlog.patch)" > ./compareResultlog.patch

echo $info
echo $timeusage