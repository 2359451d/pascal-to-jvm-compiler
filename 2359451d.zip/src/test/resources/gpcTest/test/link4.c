#include <stdio.h>

void ok ()
{
  puts ("OK");
}
