package example;

public class For3FuncTest {
    private static int a;

    private static int forFunc() {
        int result = 0;
        for (int a = 1; a <5; a++) {
            result = result + a;
        }
        return result;
    }

    public static void main(String[] args) {

    }
}
