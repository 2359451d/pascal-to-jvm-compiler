package example;

public class Plus {
    public void test(){
        boolean j = false,k = false,l = false;

        boolean i = j || (k && l);
    }
}
