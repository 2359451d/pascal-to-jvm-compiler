package example;

public class While1Test {
    private static int a;

    public static void main(String[] args) {
        a = 10;
        while (a < 20) {
            //System.out.println("value of a: "+a);
            a = a + 1;
        }
    }
}
