package example;

public class DivideByZero {
    public static void main(String[] args) {
        int i;
        i = 5 / 0;
    }
}
