package example;

public class For2Test {
    private static int a;

    public static void main(String[] args) {
        for (a = 10; a <= 20; a++) {
            System.out.println("value of a: "+a);
        }
    }
}
