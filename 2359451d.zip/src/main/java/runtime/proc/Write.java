package runtime.proc;

import runtime.RuntimeProcedure;

/**
 * Placeholder for write procedure
 */
public class Write extends RuntimeProcedure {
}
