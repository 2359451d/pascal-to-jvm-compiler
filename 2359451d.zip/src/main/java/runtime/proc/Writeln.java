package runtime.proc;

import runtime.RuntimeProcedure;

public class Writeln extends RuntimeProcedure {
}
