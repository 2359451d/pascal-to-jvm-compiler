package runtime.proc;

import runtime.RuntimeProcedure;

public class Readln extends RuntimeProcedure {
}
