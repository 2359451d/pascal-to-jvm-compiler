package runtime.proc;

import runtime.RuntimeProcedure;

public class Read extends RuntimeProcedure {
}
