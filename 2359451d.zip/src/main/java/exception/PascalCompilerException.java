package exception;

public class PascalCompilerException extends Exception {

    public PascalCompilerException() {
    }

    public PascalCompilerException(String message) {
        super(message);
    }
}
