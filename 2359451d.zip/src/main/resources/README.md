# Directory Description

Temporary Dir storing the source Pascal programs for test & usage

Correct Path to store these programs should be under `src/test/resources`.

**Refator TBC**