# User manual

Describe how to use your software, if this makes sense for your code. Almost all projects should have at least some instructions on how to run the code. More extensive instructions can be provided here.

#  ==============Template Organise TBC==============

cover how to use the compiler, how to regenerate parser&lexer if needed? (extension: how to use the compiler/commandline tool, generate AST etc.)