#!/bin/bash

java -jar ./target/pascal-to-jvm-compiler-jar-with-dependencies.jar $1 $2